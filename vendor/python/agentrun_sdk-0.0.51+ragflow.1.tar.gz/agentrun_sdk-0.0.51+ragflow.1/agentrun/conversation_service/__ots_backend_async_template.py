"""OTS 存储后端。

封装 TableStore SDK 的底层操作，负责五张表的建表和 CRUD。
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from tablestore import AsyncOTSClient  # type: ignore[import-untyped]
from tablestore import BatchWriteRowRequest  # type: ignore[import-untyped]
from tablestore import (
    CapacityUnit,
    ComparatorType,
    Condition,
    DeleteRowItem,
    Direction,
    INF_MAX,
    INF_MIN,
    OTSClient,
    OTSServiceError,
    PK_AUTO_INCR,
    ReservedThroughput,
    ReturnType,
    Row,
    RowExistenceExpectation,
    SecondaryIndexMeta,
    SecondaryIndexType,
    SingleColumnCondition,
    TableInBatchWriteRowItem,
    TableMeta,
    TableOptions,
)

from agentrun.conversation_service.model import (
    CHECKPOINT_BLOBS_SCHEMA_VERSION,
    CHECKPOINT_SCHEMA_VERSION,
    CHECKPOINT_WRITES_SCHEMA_VERSION,
    CONVERSATION_SCHEMA_VERSION,
    ConversationEvent,
    ConversationSession,
    DEFAULT_APP_STATE_TABLE,
    DEFAULT_CHECKPOINT_BLOBS_TABLE,
    DEFAULT_CHECKPOINT_TABLE,
    DEFAULT_CHECKPOINT_WRITES_TABLE,
    DEFAULT_CONVERSATION_SEARCH_INDEX,
    DEFAULT_CONVERSATION_SECONDARY_INDEX,
    DEFAULT_CONVERSATION_TABLE,
    DEFAULT_EVENT_TABLE,
    DEFAULT_STATE_SEARCH_INDEX,
    DEFAULT_STATE_TABLE,
    DEFAULT_USER_STATE_TABLE,
    EVENT_SCHEMA_VERSION,
    SCHEMA_VERSION_COLUMN,
    STATE_SCHEMA_VERSION,
    StateData,
    StateScope,
)
from agentrun.conversation_service.utils import (
    deserialize_state,
    from_chunks,
    MAX_COLUMN_SIZE,
    nanoseconds_timestamp,
    serialize_state,
    to_chunks,
)

logger = logging.getLogger(__name__)

# OTS BatchWriteRow 每批最多 200 行
_BATCH_WRITE_LIMIT = 200


class OTSBackend:
    """TableStore 存储后端。

    封装 OTS SDK 底层操作，理解表结构，提供五张表的 CRUD。
    同时提供异步（_async 后缀）和同步方法。

    Args:
        ots_client: 预构建的 OTS SDK 同步客户端实例（同步方法使用）。
        table_prefix: 表名前缀，用于多租户隔离。
        async_ots_client: 预构建的 OTS SDK 异步客户端实例（异步方法使用）。
    """

    def __init__(
        self,
        ots_client: Optional[OTSClient] = None,
        table_prefix: str = "",
        *,
        async_ots_client: Optional[AsyncOTSClient] = None,
    ) -> None:
        self._client = ots_client
        self._async_client = async_ots_client
        self._table_prefix = table_prefix

        # 根据前缀生成实际表名
        self._conversation_table = f"{table_prefix}{DEFAULT_CONVERSATION_TABLE}"
        self._event_table = f"{table_prefix}{DEFAULT_EVENT_TABLE}"
        self._state_table = f"{table_prefix}{DEFAULT_STATE_TABLE}"
        self._app_state_table = f"{table_prefix}{DEFAULT_APP_STATE_TABLE}"
        self._user_state_table = f"{table_prefix}{DEFAULT_USER_STATE_TABLE}"
        self._conversation_secondary_index = (
            f"{table_prefix}{DEFAULT_CONVERSATION_SECONDARY_INDEX}"
        )
        self._conversation_search_index = (
            f"{table_prefix}{DEFAULT_CONVERSATION_SEARCH_INDEX}"
        )
        self._state_search_index = f"{table_prefix}{DEFAULT_STATE_SEARCH_INDEX}"

        # LangGraph checkpoint 表
        self._checkpoint_table = f"{table_prefix}{DEFAULT_CHECKPOINT_TABLE}"
        self._checkpoint_writes_table = (
            f"{table_prefix}{DEFAULT_CHECKPOINT_WRITES_TABLE}"
        )
        self._checkpoint_blobs_table = (
            f"{table_prefix}{DEFAULT_CHECKPOINT_BLOBS_TABLE}"
        )

    # -----------------------------------------------------------------------
    # 建表 / Table creation
    # -----------------------------------------------------------------------

    async def init_tables_async(self) -> None:
        """创建五张表、二级索引和多元索引（异步）。

        包括 Conversation 二级索引、Conversation 多元索引和 State 多元索引。
        表或索引已存在时跳过（catch OTSServiceError 并 log warning）。
        """
        await self._create_conversation_table_async()
        await self._create_event_table_async()
        await self._create_state_table_async(
            self._state_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
            ],
        )
        await self._create_state_table_async(
            self._app_state_table,
            [("agent_id", "STRING")],
        )
        await self._create_state_table_async(
            self._user_state_table,
            [("agent_id", "STRING"), ("user_id", "STRING")],
        )
        await self.init_search_index_async()

    async def init_core_tables_async(self) -> None:
        """创建核心表（Conversation + Event）和二级索引（异步）。"""
        await self._create_conversation_table_async()
        await self._create_event_table_async()

    async def init_state_tables_async(self) -> None:
        """创建三张 State 表（异步）。"""
        await self._create_state_table_async(
            self._state_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
            ],
        )
        await self._create_state_table_async(
            self._app_state_table,
            [("agent_id", "STRING")],
        )
        await self._create_state_table_async(
            self._user_state_table,
            [("agent_id", "STRING"), ("user_id", "STRING")],
        )

    async def init_search_index_async(self) -> None:
        """创建 Conversation 和 State 多元索引（异步）。

        索引已存在时跳过，可重复调用。
        """
        await self._create_conversation_search_index_async()
        await self._create_state_search_index_async()

    async def init_conversation_search_index_async(self) -> None:
        """仅创建 Conversation 多元索引（异步）。

        索引已存在时跳过，可重复调用。
        """
        await self._create_conversation_search_index_async()

    async def init_checkpoint_tables_async(self) -> None:
        """创建 LangGraph checkpoint 相关的 3 张表（异步）。

        包含 checkpoint、checkpoint_writes、checkpoint_blobs 表。
        表已存在时跳过，可重复调用。
        """
        await self._create_checkpoint_table_async()
        await self._create_checkpoint_writes_table_async()
        await self._create_checkpoint_blobs_table_async()

    async def _create_checkpoint_table_async(self) -> None:
        """创建 checkpoint 表（异步）。

        PK: thread_id (STRING), checkpoint_ns (STRING), checkpoint_id (STRING)
        """
        table_meta = TableMeta(
            self._checkpoint_table,
            [
                ("thread_id", "STRING"),
                ("checkpoint_ns", "STRING"),
                ("checkpoint_id", "STRING"),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta, table_options, reserved_throughput
            )
            logger.info("Created table: %s", self._checkpoint_table)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._checkpoint_table,
                )
            else:
                raise

    async def _create_checkpoint_writes_table_async(self) -> None:
        """创建 checkpoint_writes 表（异步）。

        PK: thread_id (STRING), checkpoint_ns (STRING),
            checkpoint_id (STRING), task_idx (STRING)
        """
        table_meta = TableMeta(
            self._checkpoint_writes_table,
            [
                ("thread_id", "STRING"),
                ("checkpoint_ns", "STRING"),
                ("checkpoint_id", "STRING"),
                ("task_idx", "STRING"),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta, table_options, reserved_throughput
            )
            logger.info("Created table: %s", self._checkpoint_writes_table)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._checkpoint_writes_table,
                )
            else:
                raise

    async def _create_checkpoint_blobs_table_async(self) -> None:
        """创建 checkpoint_blobs 表（异步）。

        PK: thread_id (STRING), checkpoint_ns (STRING),
            channel (STRING), version (STRING)
        """
        table_meta = TableMeta(
            self._checkpoint_blobs_table,
            [
                ("thread_id", "STRING"),
                ("checkpoint_ns", "STRING"),
                ("channel", "STRING"),
                ("version", "STRING"),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta, table_options, reserved_throughput
            )
            logger.info("Created table: %s", self._checkpoint_blobs_table)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._checkpoint_blobs_table,
                )
            else:
                raise

    async def _create_conversation_table_async(self) -> None:
        """创建 Conversation 表 + 二级索引（异步）。"""
        table_meta = TableMeta(
            self._conversation_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
            ],
            # 二级索引引用的非 PK 列必须声明为 defined_columns
            defined_columns=[
                ("updated_at", "INTEGER"),
                ("summary", "STRING"),
                ("labels", "STRING"),
                ("framework", "STRING"),
                ("extensions", "STRING"),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        # 二级索引：按 updated_at 排序
        secondary_index_meta = SecondaryIndexMeta(
            self._conversation_secondary_index,
            [
                "agent_id",
                "user_id",
                "updated_at",
                "session_id",
            ],
            [
                "summary",
                "labels",
                "framework",
                "extensions",
            ],
            index_type=SecondaryIndexType.GLOBAL_INDEX,
        )

        try:
            await self._async_client.create_table(
                table_meta,
                table_options,
                reserved_throughput,
                secondary_indexes=[secondary_index_meta],
            )
            logger.info(
                "Created table: %s with secondary index: %s",
                self._conversation_table,
                self._conversation_secondary_index,
            )
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._conversation_table,
                )
            else:
                raise

    async def _create_event_table_async(self) -> None:
        """创建 Event 表（seq_id 为 AUTO_INCREMENT）（异步）。"""
        table_meta = TableMeta(
            self._event_table,
            [
                ("agent_id", "STRING"),
                ("user_id", "STRING"),
                ("session_id", "STRING"),
                ("seq_id", "INTEGER", PK_AUTO_INCR),
            ],
        )
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta,
                table_options,
                reserved_throughput,
            )
            logger.info("Created table: %s", self._event_table)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    self._event_table,
                )
            else:
                raise

    async def _create_state_table_async(
        self,
        table_name: str,
        pk_schema: list[tuple[str, str]],
    ) -> None:
        """创建 State 类型表（通用方法）（异步）。"""
        table_meta = TableMeta(table_name, pk_schema)
        table_options = TableOptions()
        reserved_throughput = ReservedThroughput(CapacityUnit(0, 0))

        try:
            await self._async_client.create_table(
                table_meta,
                table_options,
                reserved_throughput,
            )
            logger.info("Created table: %s", table_name)
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Table %s already exists, skipping.",
                    table_name,
                )
            else:
                raise

    async def _create_conversation_search_index_async(self) -> None:
        """创建 Conversation 表的多元索引（异步）。

        多元索引支持全文检索 summary、精确匹配过滤 labels/framework/is_pinned、
        范围查询 updated_at/created_at、跨 user 查询等场景。
        索引已存在时跳过。
        """
        from tablestore import AnalyzerType  # type: ignore[import-untyped]
        from tablestore import FieldType  # type: ignore[import-untyped]
        from tablestore import IndexSetting  # type: ignore[import-untyped]
        from tablestore import SortOrder  # type: ignore[import-untyped]
        from tablestore import FieldSchema
        from tablestore import (
            FieldSort as OTSFieldSort,
        )  # type: ignore[import-untyped]
        from tablestore import SearchIndexMeta
        from tablestore import Sort as OTSSort  # type: ignore[import-untyped]

        fields = [
            FieldSchema(
                "agent_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "user_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "session_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "updated_at",
                FieldType.LONG,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "created_at",
                FieldType.LONG,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "is_pinned",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "framework",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "summary",
                FieldType.TEXT,
                index=True,
                analyzer=AnalyzerType.SINGLEWORD,
            ),
            FieldSchema(
                "labels",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
        ]

        index_setting = IndexSetting(routing_fields=["agent_id"])
        index_sort = OTSSort(
            sorters=[OTSFieldSort("updated_at", sort_order=SortOrder.DESC)]
        )
        index_meta = SearchIndexMeta(
            fields,
            index_setting=index_setting,
            index_sort=index_sort,
        )

        try:
            await self._async_client.create_search_index(
                self._conversation_table,
                self._conversation_search_index,
                index_meta,
            )
            logger.info(
                "Created search index: %s on table: %s",
                self._conversation_search_index,
                self._conversation_table,
            )
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Search index %s already exists, skipping.",
                    self._conversation_search_index,
                )
            else:
                raise

    async def _create_state_search_index_async(self) -> None:
        """创建 State 表的多元索引（异步）。

        支持按 session_id 独立精确匹配查询，不受主键前缀限制。
        索引已存在时跳过。
        """
        from tablestore import FieldType  # type: ignore[import-untyped]
        from tablestore import IndexSetting  # type: ignore[import-untyped]
        from tablestore import SortOrder  # type: ignore[import-untyped]
        from tablestore import FieldSchema
        from tablestore import (
            FieldSort as OTSFieldSort,
        )  # type: ignore[import-untyped]
        from tablestore import SearchIndexMeta
        from tablestore import Sort as OTSSort  # type: ignore[import-untyped]

        fields = [
            FieldSchema(
                "agent_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "user_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "session_id",
                FieldType.KEYWORD,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "created_at",
                FieldType.LONG,
                index=True,
                enable_sort_and_agg=True,
            ),
            FieldSchema(
                "updated_at",
                FieldType.LONG,
                index=True,
                enable_sort_and_agg=True,
            ),
        ]

        index_setting = IndexSetting(routing_fields=["agent_id"])
        index_sort = OTSSort(
            sorters=[OTSFieldSort("updated_at", sort_order=SortOrder.DESC)]
        )
        index_meta = SearchIndexMeta(
            fields,
            index_setting=index_setting,
            index_sort=index_sort,
        )

        try:
            await self._async_client.create_search_index(
                self._state_table,
                self._state_search_index,
                index_meta,
            )
            logger.info(
                "Created search index: %s on table: %s",
                self._state_search_index,
                self._state_table,
            )
        except OTSServiceError as e:
            if "already exist" in str(e).lower() or (
                hasattr(e, "code") and e.code == "OTSObjectAlreadyExist"
            ):
                logger.warning(
                    "Search index %s already exists, skipping.",
                    self._state_search_index,
                )
            else:
                raise

    # -----------------------------------------------------------------------
    # Session CRUD
    # -----------------------------------------------------------------------

    async def put_session_async(self, session: ConversationSession) -> None:
        """PutRow 写入/覆盖 Session 行（异步）。"""
        primary_key = [
            ("agent_id", session.agent_id),
            ("user_id", session.user_id),
            ("session_id", session.session_id),
        ]

        attribute_columns = [
            (SCHEMA_VERSION_COLUMN, CONVERSATION_SCHEMA_VERSION),
            ("created_at", session.created_at),
            ("updated_at", session.updated_at),
            ("is_pinned", session.is_pinned),
            ("version", session.version),
        ]

        if session.summary is not None:
            attribute_columns.append(("summary", session.summary))
        if session.labels is not None:
            attribute_columns.append(("labels", session.labels))
        if session.framework is not None:
            attribute_columns.append(("framework", session.framework))
        if session.extensions is not None:
            attribute_columns.append((
                "extensions",
                json.dumps(session.extensions, ensure_ascii=False),
            ))

        row = Row(primary_key, attribute_columns)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.put_row(
            self._conversation_table, row, condition
        )

    async def get_session_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> Optional[ConversationSession]:
        """GetRow 点读 Session（异步）。"""
        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
        ]

        _, row, _ = await self._async_client.get_row(
            self._conversation_table,
            primary_key,
            max_version=1,
        )

        if row is None or row.primary_key is None:
            return None

        return self._row_to_session(row)

    async def delete_session_row_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> None:
        """DeleteRow 删除 Session 单行（不含级联）（异步）。"""
        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
        ]
        row = Row(primary_key)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.delete_row(
            self._conversation_table, row, condition
        )

    async def update_session_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
        columns_to_put: dict[str, Any],
        version: int,
    ) -> None:
        """UpdateRow + 乐观锁更新 Session 行（异步）。

        Args:
            agent_id: 智能体 ID。
            user_id: 用户 ID。
            session_id: 会话 ID。
            columns_to_put: 要更新的列及其值。
            version: 当前版本号（乐观锁校验）。
        """
        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
        ]

        put_cols = list(columns_to_put.items())
        update_of_attribute_columns = {"PUT": put_cols}

        row = Row(primary_key, update_of_attribute_columns)
        condition = Condition(
            RowExistenceExpectation.EXPECT_EXIST,
            SingleColumnCondition(
                "version",
                version,
                ComparatorType.EQUAL,
            ),
        )
        await self._async_client.update_row(
            self._conversation_table, row, condition
        )

    async def list_sessions_async(
        self,
        agent_id: str,
        user_id: str,
        limit: Optional[int] = None,
        order_desc: bool = True,
    ) -> list[ConversationSession]:
        """通过二级索引按 updated_at 排序扫描 Session 列表（异步）。"""

        if order_desc:
            # 倒序：从最新到最旧
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MAX),
                ("session_id", INF_MAX),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MIN),
                ("session_id", INF_MIN),
            ]
            direction = Direction.BACKWARD
        else:
            # 正序：从最旧到最新
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MIN),
                ("session_id", INF_MIN),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("updated_at", INF_MAX),
                ("session_id", INF_MAX),
            ]
            direction = Direction.FORWARD

        sessions: list[ConversationSession] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._conversation_secondary_index,
                direction,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit,
            )

            for row in rows:
                session = self._row_to_session_from_index(row)
                sessions.append(session)
                if limit is not None and len(sessions) >= limit:
                    return sessions

            if next_token is None:
                break
            next_start = next_token

        return sessions

    async def list_all_sessions_async(
        self,
        agent_id: str,
        limit: Optional[int] = None,
    ) -> list[ConversationSession]:
        """扫描 agent_id 下所有用户的 Session（主表 GetRange）（异步）。

        不走二级索引，直接扫主表。返回结果不含 events，
        适用于 ADK list_sessions(user_id=None) 场景。

        Args:
            agent_id: 智能体 ID。
            limit: 最多返回条数，None 表示全部。

        Returns:
            ConversationSession 列表。
        """
        inclusive_start = [
            ("agent_id", agent_id),
            ("user_id", INF_MIN),
            ("session_id", INF_MIN),
        ]
        exclusive_end = [
            ("agent_id", agent_id),
            ("user_id", INF_MAX),
            ("session_id", INF_MAX),
        ]

        sessions: list[ConversationSession] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._conversation_table,
                Direction.FORWARD,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit,
            )

            for row in rows:
                session = self._row_to_session(row)
                sessions.append(session)
                if limit is not None and len(sessions) >= limit:
                    return sessions

            if next_token is None:
                break
            next_start = next_token

        return sessions

    async def search_sessions_async(
        self,
        agent_id: str,
        *,
        user_id: Optional[str] = None,
        summary_keyword: Optional[str] = None,
        labels: Optional[str] = None,
        framework: Optional[str] = None,
        updated_after: Optional[int] = None,
        updated_before: Optional[int] = None,
        is_pinned: Optional[bool] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> tuple[list[ConversationSession], int]:
        """通过多元索引搜索 Session（异步）。

        支持全文搜索 summary、精确过滤 labels/framework/is_pinned、
        范围查询 updated_at 以及跨 user_id 查询。

        Args:
            agent_id: 智能体 ID（必填，作为 routing 键优化查询）。
            user_id: 用户 ID（可选，精确匹配）。
            summary_keyword: summary 关键词（全文搜索）。
            labels: 标签 JSON 字符串（精确匹配）。
            framework: 框架标识（精确匹配）。
            updated_after: 仅返回 updated_at >= 此值的记录。
            updated_before: 仅返回 updated_at < 此值的记录。
            is_pinned: 是否置顶过滤。
            limit: 最多返回条数，默认 20。
            offset: 分页偏移量，默认 0。

        Returns:
            (结果列表, 总匹配数) 二元组。
        """
        from tablestore import BoolQuery  # type: ignore[import-untyped]
        from tablestore import MatchQuery  # type: ignore[import-untyped]
        from tablestore import SortOrder  # type: ignore[import-untyped]
        from tablestore import TermQuery  # type: ignore[import-untyped]
        from tablestore import ColumnReturnType, ColumnsToGet
        from tablestore import (
            FieldSort as OTSFieldSort,
        )  # type: ignore[import-untyped]
        from tablestore import RangeQuery, SearchQuery
        from tablestore import Sort as OTSSort  # type: ignore[import-untyped]

        must_queries: list[Any] = [
            TermQuery("agent_id", agent_id),
        ]

        if user_id is not None:
            must_queries.append(TermQuery("user_id", user_id))
        if summary_keyword is not None:
            must_queries.append(MatchQuery("summary", summary_keyword))
        if labels is not None:
            must_queries.append(TermQuery("labels", labels))
        if framework is not None:
            must_queries.append(TermQuery("framework", framework))
        if is_pinned is not None:
            must_queries.append(
                TermQuery("is_pinned", "true" if is_pinned else "false")
            )
        if updated_after is not None or updated_before is not None:
            must_queries.append(
                RangeQuery(
                    "updated_at",
                    range_from=updated_after,
                    include_lower=True if updated_after is not None else None,
                    range_to=updated_before,
                    include_upper=False if updated_before is not None else None,
                )
            )

        query = BoolQuery(must_queries=must_queries)

        search_query = SearchQuery(
            query,
            sort=OTSSort(
                sorters=[OTSFieldSort("updated_at", sort_order=SortOrder.DESC)]
            ),
            limit=limit,
            offset=offset,
            get_total_count=True,
        )

        columns_to_get = ColumnsToGet(
            return_type=ColumnReturnType.ALL,
        )

        search_response = await self._async_client.search(
            self._conversation_table,
            self._conversation_search_index,
            search_query,
            columns_to_get,
        )

        sessions: list[ConversationSession] = []
        for row in search_response.rows:
            # search API 返回 (primary_key, attribute_columns) 元组，
            # 需要包装为 Row 对象以复用 _row_to_session
            if isinstance(row, tuple):
                row = Row(row[0], row[1])
            sessions.append(self._row_to_session(row))

        return sessions, search_response.total_count or 0

    # -----------------------------------------------------------------------
    # Event CRUD
    # -----------------------------------------------------------------------

    async def put_event_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
        event_type: str,
        content: dict[str, Any],
        created_at: Optional[int] = None,
        updated_at: Optional[int] = None,
        raw_event: Optional[str] = None,
    ) -> int:
        """PutRow 写入事件（seq_id AUTO_INCREMENT），返回 OTS 生成的 seq_id（异步）。

        Args:
            agent_id: 智能体 ID。
            user_id: 用户 ID。
            session_id: 会话 ID。
            event_type: 事件类型。
            content: 事件数据。
            created_at: 创建时间（纳秒时间戳），默认当前时间。
            updated_at: 更新时间（纳秒时间戳），默认当前时间。
            raw_event: 框架原生 Event 的完整 JSON 序列化（可选）。
                用于精确还原框架特定的 Event 对象（如 ADK Event）。

        Returns:
            OTS 生成的 seq_id。
        """
        now = nanoseconds_timestamp()
        if created_at is None:
            created_at = now
        if updated_at is None:
            updated_at = now

        primary_key = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
            ("seq_id", PK_AUTO_INCR),
        ]

        content_json = json.dumps(content, ensure_ascii=False)
        attribute_columns = [
            (SCHEMA_VERSION_COLUMN, EVENT_SCHEMA_VERSION),
            ("type", event_type),
            ("content", content_json),
            ("created_at", created_at),
            ("updated_at", updated_at),
            ("version", 0),
        ]

        if raw_event is not None:
            attribute_columns.append(("raw_event", raw_event))

        row = Row(primary_key, attribute_columns)
        condition = Condition(RowExistenceExpectation.IGNORE)

        # put_row 返回 (consumed, return_row)
        # 使用 ReturnType.RT_PK 让 OTS 返回自增 PK 值
        _, return_row = await self._async_client.put_row(
            self._event_table,
            row,
            condition,
            return_type=ReturnType.RT_PK,
        )

        # 从返回的主键中提取 seq_id
        seq_id: int = 0
        if return_row is not None and return_row.primary_key is not None:
            for pk_col in return_row.primary_key:
                if pk_col[0] == "seq_id":
                    seq_id = pk_col[1]  # type: ignore[assignment]
                    break

        return seq_id

    async def get_events_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
        direction: str = "FORWARD",
        limit: Optional[int] = None,
    ) -> list[ConversationEvent]:
        """GetRange 扫描事件列表（异步）。

        Args:
            agent_id: 智能体 ID。
            user_id: 用户 ID。
            session_id: 会话 ID。
            direction: 'FORWARD'（正序）或 'BACKWARD'（倒序）。
            limit: 最多返回条数。
        """
        if direction == "BACKWARD":
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MAX),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MIN),
            ]
            ots_direction = Direction.BACKWARD
        else:
            inclusive_start = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MIN),
            ]
            exclusive_end = [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
                ("seq_id", INF_MAX),
            ]
            ots_direction = Direction.FORWARD

        events: list[ConversationEvent] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._event_table,
                ots_direction,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit,
            )

            for row in rows:
                event = self._row_to_event(row)
                events.append(event)
                if limit is not None and len(events) >= limit:
                    return events

            if next_token is None:
                break
            next_start = next_token

        return events

    async def delete_events_by_session_async(
        self,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> int:
        """批量删除 Session 下所有 Event，返回删除条数（异步）。

        先 GetRange 扫出所有 PK，再分批 BatchWriteRow 删除。
        """
        # 1. 扫描所有 Event 的 PK
        inclusive_start = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
            ("seq_id", INF_MIN),
        ]
        exclusive_end = [
            ("agent_id", agent_id),
            ("user_id", user_id),
            ("session_id", session_id),
            ("seq_id", INF_MAX),
        ]

        all_pks: list[list[tuple[str, Any]]] = []
        next_start = inclusive_start

        while True:
            (
                _,
                next_token,
                rows,
                _,
            ) = await self._async_client.get_range(
                self._event_table,
                Direction.FORWARD,
                next_start,
                exclusive_end,
                columns_to_get=[],  # 只取 PK，不读属性列
                max_version=1,
            )

            for row in rows:
                all_pks.append(row.primary_key)

            if next_token is None:
                break
            next_start = next_token

        if not all_pks:
            return 0

        # 2. 分批 BatchWriteRow 删除
        deleted = 0
        for i in range(0, len(all_pks), _BATCH_WRITE_LIMIT):
            batch = all_pks[i : i + _BATCH_WRITE_LIMIT]
            delete_items = []
            for pk in batch:
                row = Row(pk)
                condition = Condition(RowExistenceExpectation.IGNORE)
                delete_items.append(DeleteRowItem(row, condition))

            request = BatchWriteRowRequest()
            request.add(
                TableInBatchWriteRowItem(self._event_table, delete_items)
            )
            await self._async_client.batch_write_row(request)
            deleted += len(batch)

        return deleted

    # -----------------------------------------------------------------------
    # State CRUD（JSON 字符串存储 + 列分片）
    # -----------------------------------------------------------------------

    async def put_state_async(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
        state: dict[str, Any],
        version: int,
    ) -> None:
        """序列化 + 列分片写入 State（异步）。

        State 以 JSON 字符串（STRING 类型）存储，不压缩。
        当 JSON 字符串超过 1.5M 字符时自动分片。

        Args:
            scope: 状态作用域（APP / USER / SESSION）。
            agent_id: 智能体 ID。
            user_id: 用户 ID（APP scope 时忽略）。
            session_id: 会话 ID（APP/USER scope 时忽略）。
            state: 状态字典。
            version: 当前版本号（乐观锁校验，首次写入传 0）。
        """
        table_name, primary_key = self._resolve_state_table_and_pk(
            scope, agent_id, user_id, session_id
        )

        now = nanoseconds_timestamp()
        state_json = serialize_state(state)

        put_cols: list[tuple[str, Any]] = [
            (SCHEMA_VERSION_COLUMN, STATE_SCHEMA_VERSION),
            ("updated_at", now),
            ("version", version + 1),
        ]

        # 首次写入需要 created_at
        if version == 0:
            put_cols.append(("created_at", now))

        if len(state_json) <= MAX_COLUMN_SIZE:
            # 不分片
            new_chunk_count = 0
            put_cols.append(("chunk_count", 0))
            put_cols.append(("state", state_json))
        else:
            # 分片
            chunks = to_chunks(state_json)
            new_chunk_count = len(chunks)
            put_cols.append(("chunk_count", new_chunk_count))
            for idx, chunk in enumerate(chunks):
                put_cols.append((f"state_{idx}", chunk))

        update_of_attribute_columns: dict[str, Any] = {"PUT": put_cols}

        # 如果是更新（version > 0），需要清理旧的分片列
        delete_cols: list[str] = []
        if version > 0:
            old_chunk_count = await self._get_chunk_count_async(
                table_name, primary_key
            )

            if new_chunk_count == 0 and old_chunk_count > 0:
                # 旧的有分片，新的不分片：删除所有 state_N 列
                for i in range(old_chunk_count):
                    delete_cols.append(f"state_{i}")
            elif new_chunk_count > 0 and old_chunk_count == 0:
                # 旧的不分片，新的有分片：删除 state 列
                delete_cols.append("state")
            elif new_chunk_count > 0 and old_chunk_count > new_chunk_count:
                # 都分片，但旧的分片更多：删除多余分片列
                for i in range(new_chunk_count, old_chunk_count):
                    delete_cols.append(f"state_{i}")

        if delete_cols:
            update_of_attribute_columns["DELETE_ALL"] = delete_cols

        row = Row(primary_key, update_of_attribute_columns)

        if version == 0:
            # 首次写入
            condition = Condition(RowExistenceExpectation.IGNORE)
        else:
            condition = Condition(
                RowExistenceExpectation.EXPECT_EXIST,
                SingleColumnCondition(
                    "version",
                    version,
                    ComparatorType.EQUAL,
                ),
            )

        await self._async_client.update_row(table_name, row, condition)

    async def get_state_async(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> Optional[StateData]:
        """读取 + 拼接分片 + 反序列化 State（异步）。"""
        table_name, primary_key = self._resolve_state_table_and_pk(
            scope, agent_id, user_id, session_id
        )

        _, row, _ = await self._async_client.get_row(
            table_name,
            primary_key,
            max_version=1,
        )

        if row is None or row.primary_key is None:
            return None

        attrs = self._attrs_to_dict(row.attribute_columns)

        chunk_count = attrs.get("chunk_count", 0)
        if chunk_count == 0:
            raw_state = attrs.get("state")
            if raw_state is None:
                return None
            state = deserialize_state(str(raw_state))
        else:
            chunks: list[str] = []
            for i in range(chunk_count):
                chunk = attrs.get(f"state_{i}")
                if chunk is None:
                    raise ValueError(f"Missing state chunk: state_{i}")
                chunks.append(str(chunk))
            merged_str = from_chunks(chunks)
            state = deserialize_state(merged_str)

        return StateData(
            state=state,
            created_at=attrs.get("created_at", 0),
            updated_at=attrs.get("updated_at", 0),
            version=attrs.get("version", 0),
        )

    async def delete_state_row_async(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> None:
        """删除 State 行（异步）。"""
        table_name, primary_key = self._resolve_state_table_and_pk(
            scope, agent_id, user_id, session_id
        )
        row = Row(primary_key)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.delete_row(table_name, row, condition)

    # -----------------------------------------------------------------------
    # Checkpoint CRUD（LangGraph）
    # -----------------------------------------------------------------------

    async def put_checkpoint_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        checkpoint_id: str,
        *,
        checkpoint_type: str,
        checkpoint_data: str,
        metadata_json: str,
        parent_checkpoint_id: str = "",
    ) -> None:
        """写入/覆盖 checkpoint 行（异步）。"""
        primary_key = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", checkpoint_id),
        ]
        attribute_columns = [
            (SCHEMA_VERSION_COLUMN, CHECKPOINT_SCHEMA_VERSION),
            ("checkpoint_type", checkpoint_type),
            ("checkpoint_data", checkpoint_data),
            ("metadata", metadata_json),
            ("parent_checkpoint_id", parent_checkpoint_id),
        ]
        row = Row(primary_key, attribute_columns)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.put_row(self._checkpoint_table, row, condition)

    async def get_checkpoint_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        checkpoint_id: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """读取单条 checkpoint（异步）。

        若 checkpoint_id 为 None，使用 GetRange 获取最新的（按 checkpoint_id 倒序）。

        Returns:
            包含 checkpoint 字段的字典，或 None。
        """
        if checkpoint_id is not None:
            primary_key = [
                ("thread_id", thread_id),
                ("checkpoint_ns", checkpoint_ns),
                ("checkpoint_id", checkpoint_id),
            ]
            _, row, _ = await self._async_client.get_row(
                self._checkpoint_table, primary_key, max_version=1
            )
            if row is None or row.primary_key is None:
                return None
            pk = self._pk_to_dict(row.primary_key)
            attrs = self._attrs_to_dict(row.attribute_columns)
            return {**pk, **attrs}

        # checkpoint_id 为 None -> 取最新
        inclusive_start = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", INF_MAX),
        ]
        exclusive_end = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", INF_MIN),
        ]
        _, _, rows, _ = await self._async_client.get_range(
            self._checkpoint_table,
            Direction.BACKWARD,
            inclusive_start,
            exclusive_end,
            max_version=1,
            limit=1,
        )
        if not rows:
            return None
        row = rows[0]
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)
        return {**pk, **attrs}

    async def list_checkpoints_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        *,
        limit: int = 10,
        before: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """按 checkpoint_id 倒序列出 checkpoint（异步）。

        Args:
            thread_id: 线程 ID。
            checkpoint_ns: checkpoint 命名空间。
            limit: 最多返回条数。
            before: 仅返回 checkpoint_id < before 的记录。
        """
        if before is not None:
            start_id: Any = before
        else:
            start_id = INF_MAX

        inclusive_start = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", start_id),
        ]
        exclusive_end = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", INF_MIN),
        ]

        results: list[dict[str, Any]] = []
        next_start = inclusive_start

        while len(results) < limit:
            _, next_token, rows, _ = await self._async_client.get_range(
                self._checkpoint_table,
                Direction.BACKWARD,
                next_start,
                exclusive_end,
                max_version=1,
                limit=limit - len(results),
            )

            for row in rows:
                pk = self._pk_to_dict(row.primary_key)
                # 如果 before 指定了精确值，跳过它本身
                if before is not None and pk.get("checkpoint_id") == before:
                    continue
                attrs = self._attrs_to_dict(row.attribute_columns)
                results.append({**pk, **attrs})
                if len(results) >= limit:
                    break

            if next_token is None:
                break
            next_start = next_token

        return results

    async def put_checkpoint_writes_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        checkpoint_id: str,
        writes: list[dict[str, Any]],
    ) -> None:
        """批量写入 checkpoint writes（异步）。

        Args:
            writes: 每个元素是 dict，包含 task_idx, task_id, task_path,
                    channel, value_type, value_data 字段。
        """
        if not writes:
            return

        for i in range(0, len(writes), _BATCH_WRITE_LIMIT):
            batch = writes[i : i + _BATCH_WRITE_LIMIT]
            from tablestore import PutRowItem  # type: ignore[import-untyped]

            put_items = []
            for w in batch:
                pk = [
                    ("thread_id", thread_id),
                    ("checkpoint_ns", checkpoint_ns),
                    ("checkpoint_id", checkpoint_id),
                    ("task_idx", w["task_idx"]),
                ]
                attrs = [
                    (SCHEMA_VERSION_COLUMN, CHECKPOINT_WRITES_SCHEMA_VERSION),
                    ("task_id", w["task_id"]),
                    ("task_path", w.get("task_path", "")),
                    ("channel", w["channel"]),
                    ("value_type", w["value_type"]),
                    ("value_data", w["value_data"]),
                ]
                row = Row(pk, attrs)
                condition = Condition(RowExistenceExpectation.IGNORE)
                put_items.append(PutRowItem(row, condition))

            request = BatchWriteRowRequest()
            request.add(
                TableInBatchWriteRowItem(
                    self._checkpoint_writes_table, put_items
                )
            )
            await self._async_client.batch_write_row(request)

    async def get_checkpoint_writes_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        checkpoint_id: str,
    ) -> list[dict[str, Any]]:
        """读取指定 checkpoint 的所有 writes（异步）。"""
        inclusive_start = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", checkpoint_id),
            ("task_idx", INF_MIN),
        ]
        exclusive_end = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("checkpoint_id", checkpoint_id),
            ("task_idx", INF_MAX),
        ]

        results: list[dict[str, Any]] = []
        next_start = inclusive_start

        while True:
            _, next_token, rows, _ = await self._async_client.get_range(
                self._checkpoint_writes_table,
                Direction.FORWARD,
                next_start,
                exclusive_end,
                max_version=1,
            )
            for row in rows:
                pk = self._pk_to_dict(row.primary_key)
                attrs = self._attrs_to_dict(row.attribute_columns)
                results.append({**pk, **attrs})

            if next_token is None:
                break
            next_start = next_token

        return results

    async def put_checkpoint_blob_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        channel: str,
        version: str,
        *,
        blob_type: str,
        blob_data: str,
    ) -> None:
        """写入/覆盖 checkpoint blob 行（异步）。"""
        primary_key = [
            ("thread_id", thread_id),
            ("checkpoint_ns", checkpoint_ns),
            ("channel", channel),
            ("version", version),
        ]
        attribute_columns = [
            (SCHEMA_VERSION_COLUMN, CHECKPOINT_BLOBS_SCHEMA_VERSION),
            ("blob_type", blob_type),
            ("blob_data", blob_data),
        ]
        row = Row(primary_key, attribute_columns)
        condition = Condition(RowExistenceExpectation.IGNORE)
        await self._async_client.put_row(
            self._checkpoint_blobs_table, row, condition
        )

    async def get_checkpoint_blobs_async(
        self,
        thread_id: str,
        checkpoint_ns: str,
        channel_versions: dict[str, str],
    ) -> dict[str, dict[str, str]]:
        """批量读取 checkpoint blobs（异步）。

        Args:
            channel_versions: {channel: version} 映射。

        Returns:
            {channel: {"blob_type": ..., "blob_data": ...}} 映射。
        """
        if not channel_versions:
            return {}

        from tablestore import (  # type: ignore[import-untyped]
            BatchGetRowRequest,
            TableInBatchGetRowItem,
        )

        results: dict[str, dict[str, str]] = {}
        items = list(channel_versions.items())

        # OTS BatchGetRow 每次最多 100 行
        batch_limit = 100
        for i in range(0, len(items), batch_limit):
            batch = items[i : i + batch_limit]
            rows_to_get = []
            for ch, ver in batch:
                pk = [
                    ("thread_id", thread_id),
                    ("checkpoint_ns", checkpoint_ns),
                    ("channel", ch),
                    ("version", str(ver)),
                ]
                rows_to_get.append(pk)

            table_item = TableInBatchGetRowItem(
                self._checkpoint_blobs_table,
                rows_to_get,
                max_version=1,
            )
            request = BatchGetRowRequest()
            request.add(table_item)
            response = await self._async_client.batch_get_row(request)

            table_results = response.get_result_by_table(
                self._checkpoint_blobs_table
            )
            for item in table_results:
                if not item.is_ok or item.row is None:
                    continue
                pk = self._pk_to_dict(item.row.primary_key)
                attrs = self._attrs_to_dict(item.row.attribute_columns)
                channel_name = pk.get("channel", "")
                results[channel_name] = {
                    "blob_type": attrs.get("blob_type", ""),
                    "blob_data": attrs.get("blob_data", ""),
                }

        return results

    async def delete_thread_checkpoints_async(
        self,
        thread_id: str,
    ) -> None:
        """删除指定 thread_id 的所有 checkpoint 相关数据（异步）。

        扫描并删除 checkpoint、checkpoint_writes、checkpoint_blobs 三张表中
        所有以 thread_id 为分区键的行。
        """
        await self._scan_and_delete_async(
            self._checkpoint_table,
            [
                ("thread_id", thread_id),
                ("checkpoint_ns", INF_MIN),
                ("checkpoint_id", INF_MIN),
            ],
            [
                ("thread_id", thread_id),
                ("checkpoint_ns", INF_MAX),
                ("checkpoint_id", INF_MAX),
            ],
        )
        await self._scan_and_delete_async(
            self._checkpoint_writes_table,
            [
                ("thread_id", thread_id),
                ("checkpoint_ns", INF_MIN),
                ("checkpoint_id", INF_MIN),
                ("task_idx", INF_MIN),
            ],
            [
                ("thread_id", thread_id),
                ("checkpoint_ns", INF_MAX),
                ("checkpoint_id", INF_MAX),
                ("task_idx", INF_MAX),
            ],
        )
        await self._scan_and_delete_async(
            self._checkpoint_blobs_table,
            [
                ("thread_id", thread_id),
                ("checkpoint_ns", INF_MIN),
                ("channel", INF_MIN),
                ("version", INF_MIN),
            ],
            [
                ("thread_id", thread_id),
                ("checkpoint_ns", INF_MAX),
                ("channel", INF_MAX),
                ("version", INF_MAX),
            ],
        )

    async def _scan_and_delete_async(
        self,
        table_name: str,
        inclusive_start: list[Any],
        exclusive_end: list[Any],
    ) -> None:
        """通用扫描删除：GetRange 扫描 PK 后 BatchWriteRow 删除（异步）。"""
        all_pks: list[Any] = []
        next_start = inclusive_start

        while True:
            _, next_token, rows, _ = await self._async_client.get_range(
                table_name,
                Direction.FORWARD,
                next_start,
                exclusive_end,
                columns_to_get=[],
                max_version=1,
            )
            for row in rows:
                all_pks.append(row.primary_key)
            if next_token is None:
                break
            next_start = next_token

        if not all_pks:
            return

        for i in range(0, len(all_pks), _BATCH_WRITE_LIMIT):
            batch = all_pks[i : i + _BATCH_WRITE_LIMIT]
            delete_items = []
            for pk in batch:
                row = Row(pk)
                condition = Condition(RowExistenceExpectation.IGNORE)
                delete_items.append(DeleteRowItem(row, condition))

            request = BatchWriteRowRequest()
            request.add(TableInBatchWriteRowItem(table_name, delete_items))
            await self._async_client.batch_write_row(request)

    # -----------------------------------------------------------------------
    # 内部辅助方法（I/O 相关）
    # -----------------------------------------------------------------------

    async def _get_chunk_count_async(
        self,
        table_name: str,
        primary_key: list[tuple[str, str]],
    ) -> int:
        """读取指定行的 chunk_count 值（异步）。"""
        _, row, _ = await self._async_client.get_row(
            table_name,
            primary_key,
            columns_to_get=["chunk_count"],
            max_version=1,
        )
        if row is None or row.primary_key is None:
            return 0

        attrs = self._attrs_to_dict(row.attribute_columns)
        return attrs.get("chunk_count", 0)

    # -----------------------------------------------------------------------
    # 内部辅助方法（纯计算，不涉及 I/O，保持同步）
    # -----------------------------------------------------------------------

    def _resolve_state_table_and_pk(
        self,
        scope: StateScope,
        agent_id: str,
        user_id: str,
        session_id: str,
    ) -> tuple[str, list[tuple[str, str]]]:
        """根据 scope 返回对应的表名和主键列表。"""
        if scope == StateScope.APP:
            return self._app_state_table, [
                ("agent_id", agent_id),
            ]
        elif scope == StateScope.USER:
            return self._user_state_table, [
                ("agent_id", agent_id),
                ("user_id", user_id),
            ]
        else:  # SESSION
            return self._state_table, [
                ("agent_id", agent_id),
                ("user_id", user_id),
                ("session_id", session_id),
            ]

    @staticmethod
    def _attrs_to_dict(
        attribute_columns: list[Any],
    ) -> dict[str, Any]:
        """将 OTS 属性列列表转换为字典。

        OTS 返回的属性列格式为 [(name, value, timestamp), ...]
        """
        result: dict[str, Any] = {}
        if attribute_columns is None:
            return result
        for col in attribute_columns:
            # col 格式: (name, value, timestamp)
            name = col[0]
            value = col[1]
            result[name] = value
        return result

    @staticmethod
    def _pk_to_dict(
        primary_key: list[Any],
    ) -> dict[str, Any]:
        """将 OTS 主键列表转换为字典。"""
        result: dict[str, Any] = {}
        if primary_key is None:
            return result
        for col in primary_key:
            name = col[0]
            value = col[1]
            result[name] = value
        return result

    def _row_to_session(self, row: Row) -> ConversationSession:
        """将 OTS Row 转换为 ConversationSession。"""
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)

        extensions = None
        ext_raw = attrs.get("extensions")
        if ext_raw is not None and isinstance(ext_raw, str):
            extensions = json.loads(ext_raw)

        return ConversationSession(
            agent_id=pk["agent_id"],
            user_id=pk["user_id"],
            session_id=pk["session_id"],
            created_at=attrs.get("created_at", 0),
            updated_at=attrs.get("updated_at", 0),
            is_pinned=attrs.get("is_pinned", False),
            summary=attrs.get("summary"),
            labels=attrs.get("labels"),
            framework=attrs.get("framework"),
            extensions=extensions,
            version=attrs.get("version", 0),
        )

    def _row_to_session_from_index(self, row: Row) -> ConversationSession:
        """将二级索引 Row 转换为 ConversationSession。

        二级索引的 PK 包含 updated_at，属性列只有预定义的列。
        """
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)

        extensions = None
        ext_raw = attrs.get("extensions")
        if ext_raw is not None and isinstance(ext_raw, str):
            extensions = json.loads(ext_raw)

        return ConversationSession(
            agent_id=pk["agent_id"],
            user_id=pk["user_id"],
            session_id=pk["session_id"],
            created_at=0,  # 二级索引不含 created_at
            updated_at=pk.get("updated_at", 0),
            summary=attrs.get("summary"),
            labels=attrs.get("labels"),
            framework=attrs.get("framework"),
            extensions=extensions,
        )

    def _row_to_event(self, row: Row) -> ConversationEvent:
        """将 OTS Row 转换为 ConversationEvent。"""
        pk = self._pk_to_dict(row.primary_key)
        attrs = self._attrs_to_dict(row.attribute_columns)

        content_raw = attrs.get("content", "{}")
        if isinstance(content_raw, str):
            content = json.loads(content_raw)
        else:
            content = {}

        return ConversationEvent(
            agent_id=pk["agent_id"],
            user_id=pk["user_id"],
            session_id=pk["session_id"],
            seq_id=pk.get("seq_id"),
            type=attrs.get("type", ""),
            content=content,
            created_at=attrs.get("created_at", 0),
            updated_at=attrs.get("updated_at", 0),
            version=attrs.get("version", 0),
            raw_event=attrs.get("raw_event"),
        )
